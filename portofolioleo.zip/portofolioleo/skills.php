<?php
include_once("admin/koneksi.php");
include_once("admin/inc_fungsi.php");
?>
<!doctype html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Skills - Portfolio</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
            background-color: #eabcbc;
            font-family: 'Arial', sans-serif;
            padding-top: 70px; /* Padding for fixed navbar */
            color: #333;
        }

         
        .navbar {
            background-color: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
            padding: 0.75rem 1.5rem;
        }
        .navbar-brand {
  font-weight: bold;
  font-size: 1.5rem;
  color: rgb(0, 0, 0);
  transition: color 0.3s ease;
}

.navbar-brand:hover {
  color: #4caf50; /* Change color on hover */
}

        h1 {
            font-weight: bold;
            font-size: 2.5rem;
            color: #4d4d4d;
        }
        .skill-card {
            transition: transform 0.3s ease;
            cursor: pointer;
        }

        .skill-card:hover {
            font-weight: 300px;
            color: red;
            transform: scale(1.05);
        }
        .aset1 { z-index: -1;
    position: absolute;
    top: 30%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 5%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
}
.aset3 { z-index: -1;
  position: absolute;
    top: 70%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 15%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
}
.aset-2 { z-index: -1;
    position: absolute;
    top: 60%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 150px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
    padding-left: 55%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
    left: 25%;
}
.aset4 {
    z-index: -1;
  position: absolute;
    top: 25%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 75%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(3px); /* Menambahkan efek blur */
}

.aset:nth-child(1) {
    left: 5vw; /* Jarak dari kiri dengan satuan vw agar dinamis */
    transform: rotate(-10deg);
}

.aset2:nth-child(2) {
    right: 5vw; /* Jarak dari kanan dengan satuan vw agar dinamis */
    transform: rotate(20deg);
}

/* Animasi tetap sama */
@keyframes moveRocket {
    0% {
        transform: translateY(0) rotate(20deg);
    }
    50% {
        transform: translateY(-40px) rotate(35deg);
    }
    100% {
        transform: translateY(0) rotate(10deg);
    }
}
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark shadow fixed-top" 
    style="background-color: white; 
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    transition: background-color 0.3s ease;">


    <div class="container">
      <a class="navbar-brand text-black" style="color: rgb(0, 0, 0);" href="index.php">Leonardo</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto ">
          <li class="nav-item">
            <a class="nav-link text-black"   href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="aboutme.php">About me</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="project.php">Project</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="contact.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="skills.php">Skills</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<div class="container" style="margin-top: 100px;">
    <h1 class="text-center mb-5"><?php echo ambil_judul_skill('3')?></h1>

    <div class="row">
        <!-- Skill Card 1 -->
        <div class="col-md-4 mb-4">
            <div class="card skill-card shadow-sm">
                <div class="card-body text-center">
                    <h5 class="card-title"><?php echo ambil_skill1('3')?></h5>
                      </div>
            </div>
        </div>

        <!-- Skill Card 2 -->
        <div class="col-md-4 mb-4">
            <div class="card skill-card shadow-sm">
                <div class="card-body text-center">
                    <h5 class="card-title"><?php echo ambil_skill2('3')?></h5>
                     </div>
            </div>
        </div>

        <!-- Skill Card 3 -->
        <div class="col-md-4 mb-4">
            <div class="card skill-card shadow-sm">
                <div class="card-body text-center">
                    <h5 class="card-title"><?php echo ambil_skill3('3')?></h5>
                     </div>
            </div>
        </div>

        <!-- Skill Card 4 -->
        <div class="col-md-4 mb-4">
            <div class="card skill-card shadow-sm">
                <div class="card-body text-center">
                    <h5 class="card-title"><?php echo ambil_skill4('3')?></h5>
                     </div>
            </div>
        </div>

        <!-- Skill Card 5 -->
        <div class="col-md-4 mb-4">
            <div class="card skill-card shadow-sm">
                <div class="card-body text-center">
                    <h5 class="card-title"><?php echo ambil_skill5('3')?></h5>
                      </div>
            </div>
        </div>

        <!-- Skill Card 6 -->
        <div class="col-md-4 mb-4">
            <div class="card skill-card shadow-sm">
                <div class="card-body text-center">
                    <h5 class="card-title"><?php echo ambil_skill6('3')?></h5>
                      </div>
            </div>
        </div>
    </div>
    
</div>
<div class="aset1">
      <img src="img/aset1.png" width="200px">
    </div>
    <div class="aset-2">
      <img src="img/aset2.png" width="300px">
    </div>
    <div class="aset3">
      <img src="img/aset3.png" width="200px">
    </div>
    <div class="aset4">
      <img src="img/aset4.png" width="200px">
    </div>

</body>
</html>
