<?php
include_once("admin/koneksi.php");
include_once("admin/inc_fungsi.php");
?>
 

<!doctype html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Portfolio</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        .project-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .project-card:hover {
            transform: scale(1.05);
            box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.2);
        }

         

        footer a {
            text-decoration: none;
        }

        body {
            background-color: #eabcbc;
            font-family: 'Arial', sans-serif;
            padding-top: 70px; /* Padding for fixed navbar */
            color: #333;
            height: 100%;
            overflow-y: scroll;
        }

        h1 {
            font-weight: bold;
            font-size: 2.5rem;
            color: #4d4d4d;
        }

        footer {
            background-color: #343a40;
        }

        footer h5, footer a {
            color: #b9c98f;
        }

        .navbar {
            background-color: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
            padding: 0.75rem 1.5rem;
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }

        .card-body h5 {
            font-weight: bold;
        }
        .aset1 { z-index: -1;
    position: absolute;
    top: 30%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 5%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
}
.aset3 { z-index: -1;
  position: absolute;
    top: 70%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 15%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
}
.aset-2 { z-index: -1;
    position: absolute;
    top: 60%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 150px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
    padding-left: 55%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
    left: 25%;
}
.aset4 { z-index: -1;
  position: absolute;
    top: 25%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 75%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(3px); /* Menambahkan efek blur */
}

.aset:nth-child(1) {
    left: 5vw; /* Jarak dari kiri dengan satuan vw agar dinamis */
    transform: rotate(-10deg);
}

.aset2:nth-child(2) {
    right: 5vw; /* Jarak dari kanan dengan satuan vw agar dinamis */
    transform: rotate(20deg);
}

/* Animasi tetap sama */
@keyframes moveRocket {
    0% {
        transform: translateY(0) rotate(20deg);
    }
    50% {
        transform: translateY(-40px) rotate(35deg);
    }
    100% {
        transform: translateY(0) rotate(10deg);
    }
}
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark shadow fixed-top" 
    style="background-color: white; 
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    transition: background-color 0.3s ease;">


    <div class="container">
      <a class="navbar-brand text-black" style="color: rgb(0, 0, 0);" href="index.php">Leonardo</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto ">
          <li class="nav-item">
            <a class="nav-link text-black"   href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="aboutme.php">About me</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="project.php">Project</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="contact.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="skills.php">Skills</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

<!-- Projects Section -->
<div class="container" style="margin-top: 100px;">
    <h1 class="text-center mb-5"><?php echo ambil_judul_project('4')?> </h1>

    <div class="row justify-content-center">
        <!-- Project Card 1 -->
        <div class="col-md-4 mb-4">
            <div class="card project-card shadow-sm">
                <img src="img/porto1.png"height="200px" class="card-img-top" alt="Project 1">
                <div class="card-body">
                     
                    <p class="card-text"><?php echo ambil_porto1('4')?></p>
                     
                </div>
            </div>
        </div>

        <!-- Project Card 2 -->
        <div class="col-md-4 mb-4">
            <div class="card project-card shadow-sm">
                <img src="img/porto2.png" height="200px" class="card-img-top" alt="Project 2">
                <div class="card-body">
                      
                    <p class="card-text"><?php echo ambil_porto2('4')?></p>
                     
                </div>
            </div>
        </div>
         

    </div>
    <div class="aset1">
      <img src="img/aset1.png" width="200px">
    </div>
    <div class="aset-2">
      <img src="img/aset2.png" width="300px">
    </div>
    <div class="aset3">
      <img src="img/aset3.png" width="200px">
    </div>
    <div class="aset4">
      <img src="img/aset4.png" width="200px">
    </div>
</div>

</body>
</html>
