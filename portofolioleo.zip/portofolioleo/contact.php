<?php
// Menghubungkan ke database
include_once("admin/koneksi.php");
include_once("admin/inc_fungsi.php");

$error = "";
$sukses = "";

// Mengecek apakah form telah disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Mengambil data dari form input
    $nama = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $pesan = $_POST['message'] ?? '';

    // Validasi sederhana: mengecek apakah semua field diisi
    if ($nama == '' || $email == '' || $pesan == '') {
        $error = "Semua field harus diisi!";
    } else {
        // Query untuk memasukkan data ke dalam tabel contactme_input
        $sql = "INSERT INTO contactme_input (nama, email, pesan) VALUES ('$nama', '$email', '$pesan')";
        $q = mysqli_query($koneksi, $sql);
        
        // Mengecek apakah query berhasil dijalankan
        if ($q) {
            $sukses = "Pesan berhasil dikirim!";
        } else {
            $error = "Gagal mengirim pesan: " . mysqli_error($koneksi);
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Contact</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <style>
        body {
            background-color: #eabcbc;
            font-family: 'Arial', sans-serif;
            padding-top: 70px;
            color: #333;
            height: 100%;
            overflow-y: scroll;
        }
        .navbar {
            background-color: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
            padding: 0.75rem 1.5rem;
        }
        .navbar-brand {
  font-weight: bold;
  font-size: 1.5rem;
  color: rgb(0, 0, 0);
  transition: color 0.3s ease;
}

.navbar-brand:hover {
  color: #4caf50; /* Change color on hover */
}

        h1 {
            font-weight: bold;
            font-size: 2.5rem;
            color: #4d4d4d;
        }
        .aset1 { z-index: -1;
    position: absolute;
    top: 30%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 5%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
}
.aset3 { z-index: -1;
  position: absolute;
    top: 70%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 15%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
}
.aset-2 { z-index: -1;
    position: absolute;
    top: 60%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 150px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
    padding-left: 55%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
    left: 25%;
}
.aset4 { z-index: -1;
  position: absolute;
    top: 25%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 75%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(3px); /* Menambahkan efek blur */
}

.aset:nth-child(1) {
    left: 5vw; /* Jarak dari kiri dengan satuan vw agar dinamis */
    transform: rotate(-10deg);
}

.aset2:nth-child(2) {
    right: 5vw; /* Jarak dari kanan dengan satuan vw agar dinamis */
    transform: rotate(20deg);
}

/* Animasi tetap sama */
@keyframes moveRocket {
    0% {
        transform: translateY(0) rotate(20deg);
    }
    50% {
        transform: translateY(-40px) rotate(35deg);
    }
    100% {
        transform: translateY(0) rotate(10deg);
    }
}
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark shadow fixed-top" 
    style="background-color: white; 
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    transition: background-color 0.3s ease;">


    <div class="container">
      <a class="navbar-brand text-black" style="color: rgb(0, 0, 0);" href="index.php">Leonardo</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto ">
          <li class="nav-item">
            <a class="nav-link text-black"   href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="aboutme.php">About me</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="project.php">Project</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="contact.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="skills.php">Skills</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>


<div class="container" style="margin-top: 100px;">
    <h1 class="text-center mb-5">Contact Me</h1>

    <!-- Menampilkan pesan sukses atau error -->
    <?php if ($error): ?>
        <div class="alert alert-danger">
            <?php echo $error; ?>
        </div>
    <?php elseif ($sukses): ?>
        <div class="alert alert-success">
            <?php echo $sukses; ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6">
            <h4>Get in Touch</h4>
            <!-- Form untuk input data -->
            <form action="" method="post">
                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                </div>
                <div class="mb-3">
                    <label for="message" class="form-label">Message</label>
                    <textarea class="form-control" id="message" name="message" rows="5" placeholder="Enter your message" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
        </div>

        <div class="col-md-6">
            <h4>Contact Information</h4>
            <ul class="list-unstyled">
                <li><strong>Email:</strong> <a href="mailto:leonardocloix@gmail.com" target="_blank"><?php echo ambil_email('18'); ?></a></li>
                <li><strong>Phone:</strong> <a href="tel:+6287877947000" target="_blank"><?php echo ambil_notlp('18'); ?></a></li>
                <li><strong>LinkedIn:</strong> <a href="https://www.linkedin.com/" target="_blank"><?php echo ambil_linkedln('18'); ?></a></li>
            </ul>
            <h4 class="mt-4">Follow Me</h4>
            <ul class="list-inline">
                
                <li class="list-inline-item"><a href="https://www.instagram.com/leonardocloixx/"target="_blank" class="btn btn-outline-dark">Instagram</a></li>
                <li class="list-inline-item"><a href="https://www.tiktok.com/@leonardocloix?is_from_webapp=1&sender_device=pc"target="_blank" class="btn btn-outline-dark" target="_blank">Tiktok</a></li>
                <li class="list-inline-item"><a href="https://www.linkedin.com/" class="btn btn-outline-dark" target="_blank">LinkedIn</a></li>
            </ul>
        </div>
    </div>
    <div class="aset1">
      <img src="img/aset1.png" width="200px">
    </div>
    <div class="aset-2">
      <img src="img/aset2.png" width="300px">
    </div>
    <div class="aset3">
      <img src="img/aset3.png" width="200px">
    </div>
    <div class="aset4">
      <img src="img/aset4.png" width="200px">
    </div>
</div>
</body>
</html>
