<?php
$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "portofolio_leo";

// Menggunakan parameter yang benar di dalam fungsi mysqli_connect
$koneksi    = mysqli_connect($host, $user, $pass, $db);

if(!$koneksi){
    die("Gagal koneksi");
} 
?>
