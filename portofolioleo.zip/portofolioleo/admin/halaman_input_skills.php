<?php include("inc_header.php") ?>

<?php
$id         = "";
$judul       = "";
$skill1        = "";
$skill2        = "";
$skill3     = "";
$skill4     = "";
$skill5     = "";
$skill6     = "";
$error      = "";
$sukses     = "";

// Mengecek apakah ada data yang dikirimkan dari form
if (isset($_POST['simpan'])) {
    $judul      = $_POST['judul'];
    $skill1        =$_POST['skill1'];
    $skill2        =$_POST['skill2'];
    $skill3        =$_POST['skill3'];
    $skill4        =$_POST['skill4'];
    $skill5        =$_POST['skill5'];
    $skill6        =$_POST['skill6'];
     
     
     

    // Mendapatkan ID jika ada
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
    } else {
        $id = "";
    }

    // Debug: tampilkan ID
    echo "ID yang digunakan: " . htmlspecialchars($id) . "<br>";

    // Validasi data
    if ($judul == '' || $skill1 == '') {
        $error = "Silakan masukkan semua data yakni adalah data isi dan judul.";
    }

    // Jika tidak ada error, lakukan insert atau update
    if (empty($error)) {
        if ($id != "") {
            // Perbaiki query update
            $sql1   = "UPDATE skills SET judul = '$judul', skill1 = '$skill1', skill2 = '$skill2', skill3='$skill3', skill4='$skill4', skill5='$skill5',skill6='$skill6'  WHERE id = '$id'";
        } else {
            $sql1   = "INSERT INTO skills (judul, skill1, skill2, skill3, skill4, skill5, skill6) VALUES ('$judul', '$skill1', '$skill2', '$skill3', '$skill4', '$skill5', '$skill6' )";
        }

        // Debug: tampilkan query
        echo "Query yang dijalankan: " . htmlspecialchars($sql1) . "<br>";

        $q1 = mysqli_query($koneksi, $sql1);
        if ($q1) {
            $sukses = "Sukses memasukkan data";
        } else {
            // Debug: tampilkan error query
            $error = "Gagal cuy masukkan data: " . mysqli_error($koneksi);
        }
    }
}

// Cek apakah kita dalam mode edit
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql1   = "SELECT * FROM skills WHERE id = '$id'";
    $q1     = mysqli_query($koneksi, $sql1);
    $r1     = mysqli_fetch_array($q1);

    if ($r1) {
        $judul      = $_POST['judul'];
        $skill1        = $_POST['skill1'];
        $skill2        =$_POST['skill2'];
        $skill3        =$_POST['skill3'];
        $skill4        =$_POST['skill4'];
        $skill5        =$_POST['skill5'];
        $skill6        =$_POST['skill6'];
    } else {
        $error = "Data tidak ditemukan";
    }
}
?>

<h1>Halaman Admin Input Data</h1>
<div class="mb-3 row">
    <a href="halaman_skills.php"><< Kembali ke halaman admin</a>
</div>

<?php if ($error) { ?>
    <div class="alert alert-danger" role="alert">
        <?php echo $error ?>
    </div>
<?php } ?>

<?php if ($sukses) { ?>
    <div class="alert alert-primary" role="alert">
        <?php echo $sukses ?>
    </div>
<?php } ?>

<form action="" method="post">
    <div class="mb-3 row">
        <label for="nama" class="col-sm-2 col-form-label">judul</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="nama" value="<?php echo htmlspecialchars($judul) ?>" name="judul">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="bio" class="col-sm-2 col-form-label">skill 1</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="bio" value="<?php echo htmlspecialchars($skill1) ?>" name="skill1">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="bio" class="col-sm-2 col-form-label">skill 2</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="bio" value="<?php echo htmlspecialchars($skill2) ?>" name="skill2">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="bio" class="col-sm-2 col-form-label">skill 3</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="bio" value="<?php echo htmlspecialchars($skill3) ?>" name="skill3">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="bio" class="col-sm-2 col-form-label">skill 4</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="bio" value="<?php echo htmlspecialchars($skill4) ?>" name="skill4">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="bio" class="col-sm-2 col-form-label">skill 5</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="bio" value="<?php echo htmlspecialchars($skill5) ?>" name="skill5">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="bio" class="col-sm-2 col-form-label">skill 6</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="bio" value="<?php echo htmlspecialchars($skill5) ?>" name="skill6">
        </div>
    </div>
     
    <div class="mb-3 row">
        <div class="col-sm-2"></div>
        <div class="col-sm-10">
            <input type="submit" name="simpan" value="Simpan Data" class="btn btn-primary" />
        </div>
    </div>
</form>

<!-- Include jQuery and Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>
