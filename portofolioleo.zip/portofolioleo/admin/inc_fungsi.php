<?php

function ambil_nama($id_tulisan) {
    global $koneksi; 
    $sql1 = "SELECT * FROM halaman WHERE id = '$id_tulisan'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['nama']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_bio($id_tulisan) {
    global $koneksi; 
    $sql1 = "SELECT * FROM halaman WHERE id = '$id_tulisan'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['bio']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_button($id_tulisan) {
    global $koneksi; 
    $sql1 = "SELECT * FROM halaman WHERE id = '$id_tulisan'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['button']; 
            return $text; 
        }
    }
    
    
    return null; 
}



// buat about
function ambil_nama_about($id_nama_about) {
    global $koneksi; 
    $sql1 = "SELECT * FROM about WHERE id = '$id_nama_about'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['nama']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_bio1($id_bio1) {
    global $koneksi; 
    $sql1 = "SELECT * FROM about WHERE id = '$id_bio1'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['bio1']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_bio2($id_bio2) {
    global $koneksi; 
    $sql1 = "SELECT * FROM about WHERE id = '$id_bio2'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['bio2']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_judul($id_judul) {
    global $koneksi; 
    $sql1 = "SELECT * FROM about WHERE id = '$id_judul'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['judul']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_deskripsi1($id_deskripsi1) {
    global $koneksi; 
    $sql1 = "SELECT * FROM about WHERE id = '$id_deskripsi1'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['deskripsi1']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_deskripsi2($id_deskripsi2) {
    global $koneksi; 
    $sql1 = "SELECT * FROM about WHERE id = '$id_deskripsi2'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['deskripsi2']; 
            return $text; 
        }
    }
    
    
    return null; 
}



// buat project


function ambil_judul_project($id_judul_project) {
    global $koneksi; 
    $sql1 = "SELECT * FROM project WHERE id = '$id_judul_project'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['judul']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_porto1($id_porto1) {
    global $koneksi; 
    $sql1 = "SELECT * FROM project WHERE id = '$id_porto1'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['porto1']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_porto2($id_porto2) {
    global $koneksi; 
    $sql1 = "SELECT * FROM project WHERE id = '$id_porto2'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['porto2']; 
            return $text; 
        }
    }
    
    
    return null; 
}



// buat skill
function ambil_judul_skill($id_judul_skill) {
    global $koneksi; 
    $sql1 = "SELECT * FROM skills WHERE id = '$id_judul_skill'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['judul']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_skill1($id_skill1) {
    global $koneksi; 
    $sql1 = "SELECT * FROM skills WHERE id = '$id_skill1'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['skill1']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_skill2($id_skill2) {
    global $koneksi; 
    $sql1 = "SELECT * FROM skills WHERE id = '$id_skill2'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['skill2']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_skill3($id_skill3) {
    global $koneksi; 
    $sql1 = "SELECT * FROM skills WHERE id = '$id_skill3'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['skill3']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_skill4($id_skill4) {
    global $koneksi; 
    $sql1 = "SELECT * FROM skills WHERE id = '$id_skill4'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['skill4']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_skill5($id_skill5) {
    global $koneksi; 
    $sql1 = "SELECT * FROM skills WHERE id = '$id_skill5'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['skill5']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_skill6($id_skill6) {
    global $koneksi; 
    $sql1 = "SELECT * FROM skills WHERE id = '$id_skill6'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['skill6']; 
            return $text; 
        }
    }
    
    
    return null; 
}



// buat contactme
function ambil_judul_contactme($id_judul_contactme) {
    global $koneksi; 
    $sql1 = "SELECT * FROM contactme WHERE id = '$id_judul_contactme'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['judul']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_email($id_email) {
    global $koneksi; 
    $sql1 = "SELECT * FROM contactme WHERE id = '$id_email'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['email']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_notlp($id_notlp) {
    global $koneksi; 
    $sql1 = "SELECT * FROM contactme WHERE id = '$id_notlp'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['notlp']; 
            return $text; 
        }
    }
    
    
    return null; 
}
function ambil_linkedln($id_linkedln) {
    global $koneksi; 
    $sql1 = "SELECT * FROM contactme WHERE id = '$id_linkedln'";
    $q1 = mysqli_query($koneksi, $sql1);
    
    
    if ($q1) {
        $r1 = mysqli_fetch_array($q1);
        if ($r1) {
            $text = $r1['linkedln']; 
            return $text; 
        }
    }
    
    
    return null; 
}
?>
