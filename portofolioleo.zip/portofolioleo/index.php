
<?php
include_once("admin/koneksi.php");
include_once("admin/inc_fungsi.php");
?>
 

<!doctype html>
<html lang="en">
<head>
<style>

/* Your existing CSS goes here */

html, body {
  height: 100%;
  overflow-y: scroll; /* Enables vertical scrolling */
}


.jumbotron {
  padding: 100px 0;
  min-height: 100vh; /* Ensure jumbotron covers at least full screen height */
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
}
.navbar {
            background-color: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(10px);
            padding: 0.75rem 1.5rem;
        }
/* Navbar Brand Styling */
.navbar-brand {
  font-weight: bold;
  font-size: 1.5rem;
  color: rgb(0, 0, 0);
  transition: color 0.3s ease;
}

.navbar-brand:hover {
  color: red; /* Change color on hover */
}

/* Navbar Links Styling */
.navbar-nav .nav-link {
  color: black;
  font-size: 1.1rem;
  transition: color 0.3s ease, background-color 0.3s ease;
}

.navbar-nav .nav-link:hover {
  color: #4caf50; /* Change color on hover */
  background-color: rgba(0, 0, 0, 0.05); /* Optional hover background */
  border-radius: 5px;
}
.bgpp{
  position: absolute;
  top: 30%;
  z-index: 0;
}
.aset1 {
    position: absolute;
    top: 30%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 5%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
}
.aset3 {
  position: absolute;
    top: 70%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 15%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
}
.aset-2 {
    position: absolute;
    top: 60%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 150px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
    padding-left: 55%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(2px); /* Menambahkan efek blur */
    left: 25%;
}
.aset4 {
  position: absolute;
    top: 25%; /* Menempatkan rocket secara vertikal relatif terhadap tinggi layar */
    width: 15vw; /* Lebar rocket menggunakan satuan viewport width */
    max-width: 0px; /* Maksimal ukuran untuk rocket agar tidak terlalu besar di layar besar */
    animation: moveRocket 6s infinite ease-in-out;
     left: 75%;
    opacity: 0.8; /* Membuat rocket sedikit transparan */
    filter: blur(3px); /* Menambahkan efek blur */
}

.aset:nth-child(1) {
    left: 5vw; /* Jarak dari kiri dengan satuan vw agar dinamis */
    transform: rotate(-10deg);
}

.aset2:nth-child(2) {
    right: 5vw; /* Jarak dari kanan dengan satuan vw agar dinamis */
    transform: rotate(20deg);
}

/* Animasi tetap sama */
@keyframes moveRocket {
    0% {
        transform: translateY(0) rotate(20deg);
    }
    50% {
        transform: translateY(-40px) rotate(35deg);
    }
    100% {
        transform: translateY(0) rotate(10deg);
    }
}
 

 

 

</style>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">

  <title>Bootstrap Example</title>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark shadow fixed-top" 
    style="background-color: white; 
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    transition: background-color 0.3s ease;">


    <div class="container">
      <a class="navbar-brand text-black" style="color: rgb(0, 0, 0);" href="index.php">Leonardo</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto ">
          <li class="nav-item">
            <a class="nav-link text-black"   href="index.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="aboutme.php">About me</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="project.php">Project</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="contact.php">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-dark" href="skills.php">Skills</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>



  <!-- jumbotron -->
  <div class="jumbotron" style=" background-color:#eabcbc;">
  <h1 class="nama display-4 text-center mt-3 text-black z-1">MY PORTOFOLIO</h1>
    <img  src="img/leonardo.png"   width="200" class="rounded-circle mt-3 text-center">
    <svg class="bgpp" viewBox="0 0 200 200" width="600" xmlns="http://www.w3.org/2000/svg">
  <path fill="#FFFFFF" d="M41.1,-65.3C51.9,-65,58.3,-51.2,61.1,-38.1C63.8,-24.9,62.8,-12.5,65.4,1.5C67.9,15.4,74.1,30.9,71.9,45C69.8,59.1,59.4,71.9,46,79.6C32.6,87.2,16.3,89.6,3.9,82.9C-8.6,76.2,-17.1,60.4,-28.5,51.6C-39.9,42.9,-54.1,41.2,-63.7,33.7C-73.3,26.3,-78.2,13.2,-79.2,-0.5C-80.1,-14.3,-77.1,-28.5,-66.9,-34.9C-56.7,-41.3,-39.4,-39.8,-27.1,-39.3C-14.8,-38.7,-7.4,-39.1,3.9,-45.8C15.2,-52.6,30.3,-65.7,41.1,-65.3Z" transform="translate(100 100)" />
</svg>
    <h1 class="nama display-4 text-center mt-3 text-black"><?php echo ambil_nama('1') ?></h1>
    <p class="bio lead text-center text-black"><?php echo ambil_bio('1')?> </p>
    

     

      
    <div class="aset1">
      <img src="img/aset1.png" width="200px">
    </div>
    <div class="aset-2">
      <img src="img/aset2.png" width="300px">
    </div>
    <div class="aset3">
      <img src="img/aset3.png" width="200px">
    </div>
    <div class="aset4">
      <img src="img/aset4.png" width="200px">
    </div>
    
  </div>

  
</body>
</html>
